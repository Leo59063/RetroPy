import os
import pygame
import time
import json
import subprocess  # For DragonXSoftware emulator
from pyboy import PyBoy

# --- INITIAL SETUP ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

pygame.init()
screen = pygame.display.set_mode((1000, 700))
pygame.display.set_caption("RetroPy Launcher")

# Load icon
icon_path = os.path.join("Assets", "icon.png")
if os.path.exists(icon_path):
    icon = pygame.image.load(icon_path).convert_alpha()
    pygame.display.set_icon(icon)
else:
    print("⚠️ Icon not found:", icon_path)

# Fonts
font_title = pygame.font.SysFont("Arial", 30, bold=True)
font_desc = pygame.font.SysFont("Arial", 20)
font_hint = pygame.font.SysFont("Arial", 16)

# --- SETTINGS ---
settings = {
    "scroll_speed": 0.15,
    "zoom_center": 1.0,
    "zoom_side": 0.6,
    "sound_volume": 1.0,
    "bg_color": (15, 15, 15),
    "highlight_color": (0, 255, 0),
    "normal_color": (200, 200, 200),
    "hint_color": (180, 180, 180),
    "rom_folder": "Roms",
    "dx_emulator_path":  r"emulators\mgba.exe",
    "nes_emulator_path": r"emulators\nestopia.exe",
    "snes_emulator_path": r"emulators\snes9x.exe",
    "n64_emulator_path": r"emulators\project64.exe",
    "dolphin_path": r"emulators\dolphin.exe",
    "ppsspp_path": r"emulators\ppsspp.exe"
}
SETTINGS_FILE = "settings.json"

# Load settings
def load_settings():
    global settings
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                loaded = json.load(f)
                settings.update(loaded)
        except Exception as e:
            print("Failed to load settings:", e)

def save_settings():
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f, indent=4)
    except Exception as e:
        print("Failed to save settings:", e)

load_settings()

# --- SETTINGS MENU ---
settings_options = [
    {"name": "Scroll Speed", "key": "scroll_speed", "min": 0.05, "max": 2.0, "step": 0.05},
    {"name": "Zoom Center", "key": "zoom_center", "min": 0.5, "max": 2.0, "step": 0.1},
    {"name": "Zoom Side", "key": "zoom_side", "min": 0.3, "max": 1.0, "step": 0.05},
    {"name": "Sound Volume", "key": "sound_volume", "min": 0.0, "max": 1.0, "step": 0.1},
    {"name": "ROM Folder", "key": "rom_folder", "min": None, "max": None, "step": None},
    {"name": "mGBA Path", "key": "dx_emulator_path", "min": None, "max": None, "step": None},
    {"name": "NES Emulator Path", "key": "nes_emulator_path", "min": None, "max": None, "step": None},
    {"name": "SNES Emulator Path", "key": "snes_emulator_path", "min": None, "max": None, "step": None},
    {"name": "N64 Emulator Path", "key": "n64_emulator_path", "min": None, "max": None, "step": None},
    {"name": "Dolphin Path", "key": "dolphin_path", "min": None, "max": None, "step": None},
    {"name": "PPSSPP Path", "key": "ppsspp_path", "min": None, "max": None, "step": None}
]

current_setting_index = 0

# --- LOAD ROMS ---
def load_roms():
    roms = []
    thumbnails = {}
    descriptions = {}
    rom_folder = settings["rom_folder"]
    if not os.path.exists(rom_folder):
        os.makedirs(rom_folder)

    # Files in root folder
    for file in os.listdir(rom_folder):
        file_path = os.path.join(rom_folder, file)
        if os.path.isfile(file_path) and file.lower().endswith((".gb", ".gbc", ".gba")):
            name = os.path.splitext(file)[0]
            roms.append({"name": name, "path": file_path})
            # Cover
            cover_path = os.path.join(rom_folder, name + ".png")
            img = pygame.image.load(cover_path) if os.path.exists(cover_path) else pygame.Surface((200,200))
            if not os.path.exists(cover_path):
                img.fill((60,60,60))
            thumbnails[name] = img
            # Description
            desc_path = os.path.join(rom_folder, name + ".txt")
            descriptions[name] = open(desc_path, "r", encoding="utf-8").read().strip() if os.path.exists(desc_path) else ""

    # Files in subfolders
    for folder in os.listdir(rom_folder):
        folder_path = os.path.join(rom_folder, folder)
        if os.path.isdir(folder_path):
            for file in os.listdir(folder_path):
                if file.lower().endswith((".gb", ".gbc", ".gba")):
                    roms.append({"name": folder, "path": os.path.join(folder_path, file)})
                    # Cover
                    cover_path = os.path.join(folder_path, "cover.png")
                    img = pygame.image.load(cover_path) if os.path.exists(cover_path) else pygame.Surface((200,200))
                    if not os.path.exists(cover_path):
                        img.fill((60,60,60))
                    thumbnails[folder] = img
                    # Description
                    desc_path = os.path.join(folder_path, "desc.txt")
                    descriptions[folder] = open(desc_path, "r", encoding="utf-8").read().strip() if os.path.exists(desc_path) else ""

    if not roms:
        roms = [{"name": "No ROMs found!", "path": None}]
        thumbnails["No ROMs found!"] = pygame.Surface((200,200))
        thumbnails["No ROMs found!"].fill((60,60,60))
        descriptions["No ROMs found!"] = ""

    # Add Settings
    roms.append({"name": "Settings", "path": None})
    thumbnails["Settings"] = pygame.Surface((200,200))
    thumbnails["Settings"].fill((100,100,255))
    descriptions["Settings"] = "Configure scroll, zoom, and sound options."
    return roms, thumbnails, descriptions

roms, thumbnails, descriptions = load_roms()

# --- LAUNCH FUNCTION ---
def launch_rom(rom_item):
    if not rom_item["path"]:
        return  # Nothing to launch

    ext = os.path.splitext(rom_item["path"])[1].lower()

    # --- Game Boy / Game Boy Color ---
    if ext in (".gb", ".gbc"):
        try:
            pyboy = PyBoy(
                rom_item["path"],
                window="SDL2",
                sound_emulated=True,
                sound_volume=settings["sound_volume"]
            )
            running_pyboy = True
            while running_pyboy:
                running_pyboy = pyboy.tick()
                for py_event in pygame.event.get():
                    if py_event.type == pygame.QUIT:
                        running_pyboy = False
                time.sleep(1 / 60)
            pyboy.stop()
        except Exception as e:
            print(f"Failed to load ROM: {e}")

    # --- Game Boy Advance ---
    elif ext == ".gba":
        emulator_path = settings.get("dx_emulator_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, rom_item["path"]])
        else:
            print(f"⚠️ GBA emulator not found at {emulator_path}")

    # --- NES / Famicom Disk System ---
    elif ext in (".nes", ".fds"):
        emulator_path = settings.get("nes_emulator_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, rom_item["path"]])
        else:
            print(f"⚠️ NES emulator not found at {emulator_path}")

    # --- SNES ---
    elif ext in (".smc", ".sfc"):
        emulator_path = settings.get("snes_emulator_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, rom_item["path"]])
        else:
            print(f"⚠️ SNES emulator not found at {emulator_path}")

    # --- N64 ---
    elif ext in (".n64", ".z64"):
        emulator_path = settings.get("n64_emulator_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, rom_item["path"]])
        else:
            print(f"⚠️ N64 emulator not found at {emulator_path}")

    # --- GameCube / Wii ---
    elif ext in (".iso", ".gcm"):
        emulator_path = settings.get("dolphin_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, "-b", "-e", rom_item["path"]])
        else:
            print(f"⚠️ Dolphin emulator not found at {emulator_path}")

    # --- PSP ---
    elif ext in (".iso", ".cso"):
        emulator_path = settings.get("ppsspp_path")
        if emulator_path and os.path.exists(emulator_path):
            subprocess.run([emulator_path, rom_item["path"]])
        else:
            print(f"⚠️ PPSSPP emulator not found at {emulator_path}")

    else:
        print(f"⚠️ Unsupported ROM type: {ext}")



# --- BACKGROUND ---
bg_path = r"Assets\background.png"
background_img = pygame.image.load(bg_path).convert() if os.path.exists(bg_path) else None
if background_img:
    background_img = pygame.transform.scale(background_img, (screen.get_width(), screen.get_height()))
else:
    print("Background not found!")

# --- CAROUSEL VARIABLES ---
scroll_x = 0.0
scroll_target = 0.0
spacing = 300
center_x = screen.get_width() // 2
in_settings = False
running = True
clock = pygame.time.Clock()
easing = 0.1

# --- DRAW FUNCTIONS ---
def draw_carousel():
    if background_img:
        screen.blit(background_img, (0,0))
    else:
        screen.fill(settings["bg_color"])
    y_img, y_text = 250, 500
    num_roms = len(roms)
    selected_index = round(scroll_x) % num_roms
    # Draw side ROMs
    for i, rom in enumerate(roms):
        distance = (i - scroll_x) % num_roms
        if distance > num_roms/2: distance -= num_roms
        if i == selected_index or abs(distance) > 3: continue
        scale = max(settings["zoom_side"], settings["zoom_center"] - 0.2*abs(distance))
        alpha = max(100, 255 - 50*abs(distance))
        img = pygame.transform.scale(thumbnails[rom["name"]], (int(200*scale), int(200*scale)))
        img.set_alpha(alpha)
        rect = img.get_rect(center=(center_x+distance*spacing, y_img+20*abs(distance)))
        screen.blit(img, rect)
        color = settings["highlight_color"] if distance==0 else (150,150,150)
        text = font_desc.render(rom["name"], True, color)
        screen.blit(text, text.get_rect(center=(rect.centerx, y_text+20*abs(distance))))
    # Draw center ROM
    rom = roms[selected_index]
    img = pygame.transform.scale(thumbnails[rom["name"]], (int(200*settings["zoom_center"]*1.2), int(200*settings["zoom_center"]*1.2)))
    rect = img.get_rect(center=(center_x, y_img))
    screen.blit(img, rect)
    screen.blit(font_title.render(rom["name"], True, settings["highlight_color"]), font_title.render(rom["name"], True, settings["highlight_color"]).get_rect(center=(center_x, y_text)))
    # Description
    desc = descriptions[rom["name"]]
    for idx, line in enumerate(desc.splitlines()[:5]):
        screen.blit(font_desc.render(line, True, settings["hint_color"]), (50, 550+idx*25))
    screen.blit(font_hint.render("←/→: Scroll   ENTER: Launch/Settings   ESC: Quit", True, settings["hint_color"]), (50,650))
    pygame.display.flip()

# --- SETTINGS DRAW ---
def draw_settings():
    screen.fill(settings["bg_color"])
    screen.blit(font_title.render("Settings", True, settings["highlight_color"]), (400, 30))  # moved title up

    start_y = 100  # starting Y position for first setting (moved up)
    spacing_y = 45  # space between each setting

    for idx, opt in enumerate(settings_options):
        selected = idx == current_setting_index
        color = settings["highlight_color"] if selected else settings["normal_color"]
        val = settings[opt["key"]] if opt["key"] != "rom_folder" else settings["rom_folder"]
        value = f"{val:.2f}" if isinstance(val, float) else str(val)
        screen.blit(font_desc.render(f"{opt['name']}: {value}", True, color), (100, start_y + idx*spacing_y))
        if selected:
            pygame.draw.rect(screen, (50, 50, 50), (90, start_y + idx*spacing_y - 5, 400, 30), 2)

    # Move the keyboard hints up a little so they don't cover the last option
    screen.blit(font_hint.render("↑/↓: Select   ←/→: Adjust   ESC: Return", True, settings["hint_color"]), (50, 620))
    pygame.display.flip()

def handle_settings_input(event):
    global current_setting_index, in_settings
    opt = settings_options[current_setting_index]
    if event.key==pygame.K_UP: current_setting_index=(current_setting_index-1)%len(settings_options)
    elif event.key==pygame.K_DOWN: current_setting_index=(current_setting_index+1)%len(settings_options)
    elif event.key==pygame.K_LEFT and opt["step"] and isinstance(settings[opt["key"]],(int,float)):
        settings[opt["key"]] = max(opt["min"], settings[opt["key"]]-opt["step"]); save_settings()
    elif event.key==pygame.K_RIGHT and opt["step"] and isinstance(settings[opt["key"]],(int,float)):
        settings[opt["key"]] = min(opt["max"], settings[opt["key"]]+opt["step"]); save_settings()
    elif event.key==pygame.K_ESCAPE: in_settings=False; save_settings()

# --- MAIN LOOP ---
while running:
    num_roms = len(roms)
    if not in_settings:
        diff = (scroll_target - scroll_x) % num_roms
        if diff > num_roms/2: diff -= num_roms
        elif diff < -num_roms/2: diff += num_roms
        scroll_x += diff*easing
        scroll_x %= num_roms
        draw_carousel()
    else:
        draw_settings()

    for event in pygame.event.get():
        if event.type==pygame.QUIT: running=False
        elif event.type==pygame.KEYDOWN:
            if in_settings: handle_settings_input(event)
            else:
                if event.key==pygame.K_RIGHT: scroll_target=(scroll_target+1)%len(roms)
                elif event.key==pygame.K_LEFT: scroll_target=(scroll_target-1)%len(roms)
                elif event.key==pygame.K_RETURN:
                    rom_item = roms[round(scroll_x)%len(roms)]
                    if rom_item["name"]=="Settings": in_settings=True
                    elif rom_item["path"]: launch_rom(rom_item)
                elif event.key==pygame.K_ESCAPE: running=False

    clock.tick()

pygame.quit()

